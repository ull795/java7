package java3;

class CreditCard//parent class
{
	int cardNo=12356775;
	int pin = 2345;
}
class Hacker extends CreditCard
{
	void viewDetails()
	{
		System.out.println(cardNo);
		System.out.println(pin);
	}
}

public class Card {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hacker h=new Hacker();
		h.viewDetails();
	}

}
