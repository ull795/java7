package java3;
class Palne
{
	void takeoff()
	{
		System.out.println("plane is taking off");
	}
	void fly()
	{
		System.out.println("plane is flying");
		
	}
	void land()
	{
		System.out.println("plane is landing");
	}
}
class CargoPlane extends Palne
{
	void fly()//overridden method
	
	{
		System.out.println("palne is flying low hight");
	}
	void carryCargo()
	{
		System.out.println("plane is carring cargo");
	}
}
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CargoPlane cp = new CargoPlane();
		cp.takeoff();
		cp.fly();
		cp.land();
		cp.carryCargo();
		
		
	}

}
