package java3;
class card
{
	int cardNo = 1234556;
	int pin  = 5678;
}
class Hacker
{
	
}
class Demo10 extends card,hacker
{
	
}
public class Card3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
// multiple inheritance can not permitted in java
