package java3;
class card extends Hacker
{
	int cardNo = 1234;
	int pin  = 1234;
}
class Hacker extends card
{
	
}
public class Card2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}//cycle inheritance not permitted in inheritance

