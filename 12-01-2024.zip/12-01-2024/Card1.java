package java3;

class Credit//parent class
{
	int cardNo=12356775;
	int pin = 2345;
}
class Hack extends Credit
{
	void viewDetails()
	{
		System.out.println(cardNo);
		System.out.println(pin);
	}
}

class Demo extends Credit
{
	
}
class Demo1 extends Credit
{
	
}

public class Card1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hack h=new Hack();
		h.viewDetails();
	}

}
