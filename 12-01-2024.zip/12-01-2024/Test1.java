package java3;
class object
{
	object()
	{
		
	}
}
class Test extends object
{
	int x,y;
	Test()
	{
		x=100;
		y=200;
	}
	Test(int x,int y)
	{
		this.x= x;
		this.y = y;
	}
}
class Test0 extends Test
{
	int a,b;
	Test0()
	{
		super();
		a=300;
		b=400;
	}
	Test0(int a,int b)
	{
		this.a = a;
		this.b = b;
	}
	void disp()
	{
		System.out.println(x);
		System.out.println(y);
		System.out.println(a);
		System.out.println(y);
		
	}
}
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test0 t = new Test0();
		t.disp();

	}

}
